## Description

This program implements one state machine to toggle the LED once each second.

## Suggested Activities

* Blink the red and green LEDs in alternation.

* Change the speed that the LEDs blink.  (e.g. twice or half as fast)