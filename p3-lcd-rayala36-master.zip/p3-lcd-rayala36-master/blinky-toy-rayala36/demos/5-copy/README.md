## Description

This version of the previous demo has distinct (sets of) functions implement each state machine. 

This modularization is commonly used to make it easier to understand programs.

This modularization also can bloat the code, which, ironically, can
make short programs more difficult to understand.

## Suggested Activities

* Improve the program & comments & use of whitepace to make the
  program easier to understand.
