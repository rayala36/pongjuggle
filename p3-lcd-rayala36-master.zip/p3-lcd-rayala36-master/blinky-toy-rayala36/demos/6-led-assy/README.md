## Description

greenControl() is moved out of main.c into greenControl-c.c.  GreenControl-s.s also contains a version in assy lang.

The Makefile builds two executables.  One with the C version.  The
other uses the assy version.

## Suggested Activities

* Move more functions to assy lang.