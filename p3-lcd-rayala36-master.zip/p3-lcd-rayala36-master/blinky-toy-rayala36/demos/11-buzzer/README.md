## Description
This program just makes a buzz at 1kHz.

## Suggested activity

* Modify that a differnt tone is played when the button is pressed.

* Add a state machine the plays a sequence of different tones as time progresses (use wd timer).

* Create a siren whose tone repeatedly (and gradually) increases then decreaes.

