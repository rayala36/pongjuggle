## Description

This program implements mutliple state machines

* one to blink the led with some duty cycle

* one to modify the blink duty cycle once each second

* one to cause an event every second

## Suggested Activities

* Change the  sequence to dim-to-bright

* Simultaneously bink the red & green leds with independent brightness patterns.

* Change the speed that the brighness patterns change (faster or slower).